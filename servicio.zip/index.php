<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hotel Gamgergy</title>
    <link rel="stylesheet" href="estilos.css">
    <script src="move.js"></script>
    <img src="img/gamergy2.jpg" alt="Gamergy">


</head>

<body>
    <form action="index.php" class="formulario " method="post">


        <h1 class="formulario__titulo">Sistema de Reserva de Habitaciones</h1>

        <input type="text" name = 'usuario' class="formulario__input">
        <label for="" class="formulario__label">Nombre y Apellido</label>

        <input type="text" name = 'cedula' class="formulario__input">
        <label for="" class="formulario__label">Documento Nacional de Identidad (DNI)</label>

        <input type="password" name = 'clave' class="formulario__input">
        <label for="" class="formulario__label">
        Introduzca una clave para su identificacion (Maximo 6 caracteres)</label>


        <h2>Tipo de Habitacion</h2>


        <input type="checkbox" name="Individual">
        <td>Individual</td>
        <br>

        <input type="checkbox" name="Doble">
        <td>Doble</td>
        <br>

        <input type="checkbox" name="Triple">
        <td>Triple</td>
        <br>

        <input type="checkbox" name="Familiar">
        <td>Familiar</td>
        <br>

        <input type="checkbox" name="Suite">
        <td>Suite</td>
        <br>


        <h2 class="formulario__subtitulo">
            <h2 class="formulario__subtitulo">Opciones Extra</h2>
        </h2>


        <input type="checkbox" name="gimnasio">
        <td>Gym</td>
        <br>

        <input type="checkbox" name="Jacuzzi">
        <td>Jacuzzi</td>
        <br>

        <input type="checkbox" name="Discoteca">
        <td>Discoteca</td>
        <br>

        <input type="checkbox" name="Valet Parking">
        <td>Valet Parking</td>
        <br>

        <input type="checkbox" name="Buffet">
        <td>Buffet</td>
        <br>

        <input type="checkbox" name="Spa">
        <td>Spa</td>
        <br>

        <input type="checkbox" name="Salon de eventos">
        <td>Salon de eventos</td>

        <br>
        <br>
        <br>

        <input type="submit" onclick="PromptDemo()" class="formulario__submit">
    </form>
    </form>
<div id="php">
<?php
$servidor = 'localhost';
$usuarionombre = 'steve';   
$password = 'steve';
$bd = 'hotelgamergy';

$conexion = new mysqli($servidor, $usuarionombre, $password, $bd);

if(isset($_POST['usuario'])){
    $usuario = $_POST['usuario'];
    $cedula = $_POST['cedula'];
    $clave = $_POST['clave'];

    $sql = "INSERT INTO servicio(usuario,cedula,clave)
    values ('$usuario','$cedula','$clave')";

$conexion->query($sql);

}$conexion->connect_error;


?>
</div>
</body>

</html>