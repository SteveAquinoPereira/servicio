function PromptDemo() {
    alert("Datos Registrados, Bienvenido")
}